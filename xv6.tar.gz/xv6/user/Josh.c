#include "types.h"
#include "user.h"

int
main(int argc, char *argv[])
{
  printf(1, "Hey, I am '%s'\n", argv[0]);
 
  exit();
}
